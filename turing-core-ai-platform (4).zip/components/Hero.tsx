
import React from 'react';

const Hero: React.FC = () => {
    return (
        <section className="py-20 md:py-32 bg-slate-900">
            <div className="container mx-auto px-6 text-center">
                <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-4">
                    The Future of AI, <span className="text-cyan-400">Democratized</span>.
                </h1>
                <p className="text-lg md:text-xl text-slate-400 max-w-3xl mx-auto mb-8">
                    Turing Core is a comprehensive AI-as-a-Service platform designed to empower developers and enterprises to build the next generation of intelligent applications.
                </p>
                <div className="flex justify-center space-x-4">
                    <a href="#" className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-8 rounded-md transition-transform duration-300 transform hover:scale-105">
                        Start Building
                    </a>
                    <a href="#services" className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-8 rounded-md transition-transform duration-300 transform hover:scale-105">
                        Explore Services
                    </a>
                </div>
            </div>
        </section>
    );
};

export default Hero;
