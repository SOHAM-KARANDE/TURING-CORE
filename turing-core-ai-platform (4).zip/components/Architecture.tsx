
import React from 'react';
import Card from './ui/Card';

const CubeIcon: React.FC<{className?: string}> = ({ className = "w-10 h-10" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9" />
    </svg>
);

const CommandLineIcon: React.FC<{className?: string}> = ({ className = "w-10 h-10" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 7.5l3 2.25-3 2.25m4.5 0h3m-9 8.25h13.5A2.25 2.25 0 0021 18V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v12a2.25 2.25 0 002.25 2.25z" />
    </svg>
);

const CloudIcon: React.FC<{className?: string}> = ({ className = "w-10 h-10" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15a4.5 4.5 0 004.5 4.5H18a3.75 3.75 0 001.332-7.257 3 3 0 00-3.758-3.848 5.25 5.25 0 00-10.233 2.33A4.5 4.5 0 002.25 15z" />
    </svg>
);


const Architecture: React.FC = () => {
    const features = [
        {
            icon: <CubeIcon className="w-10 h-10 text-cyan-400" />,
            title: "Cloud-Native Foundation",
            description: "Built on a containerized architecture using Docker and Kubernetes for maximum scalability and portability."
        },
        {
            icon: <CommandLineIcon className="w-10 h-10 text-cyan-400" />,
            title: "API-First Design",
            description: "All services are accessible through well-documented REST APIs to facilitate seamless integration."
        },
        {
            icon: <CloudIcon className="w-10 h-10 text-cyan-400" />,
            title: "Scalable Infrastructure",
            description: "Leverages a multi-cloud strategy to ensure high availability, resilience, and performance across the globe."
        }
    ];

    return (
        <section id="architecture" className="py-20 bg-slate-900">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-white">Modern Technical Architecture</h2>
                    <p className="text-slate-400 mt-4 max-w-2xl mx-auto">Engineered for reliability and scale from the ground up.</p>
                </div>
                <div className="grid md:grid-cols-3 gap-8">
                    {features.map(feature => (
                        <Card key={feature.title} className="text-center">
                            <div className="flex justify-center mb-4">
                                {feature.icon}
                            </div>
                            <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                            <p className="text-slate-400">{feature.description}</p>
                        </Card>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Architecture;
