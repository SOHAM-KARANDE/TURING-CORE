
import React from 'react';
import { SERVICE_CATALOG } from '../constants';
import Card from './ui/Card';

const ServiceCatalog: React.FC = () => {
    return (
        <section id="services" className="py-20 bg-slate-900/50">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-white">"Turing Core" Service Catalog</h2>
                    <p className="text-slate-400 mt-4 max-w-2xl mx-auto">A comprehensive suite of AI tools and services inspired by industry leaders.</p>
                </div>

                {SERVICE_CATALOG.map((category) => (
                    <div key={category.name} className="mb-16">
                        <h3 className="text-2xl font-semibold text-cyan-400 mb-6 flex items-center">
                            <span className="w-3 h-3 bg-cyan-400 rounded-full mr-3"></span>
                            {category.name}
                        </h3>
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                            {category.services.map((service) => (
                                <Card key={service.title}>
                                    <div className="flex items-start space-x-4">
                                        <div className="text-cyan-400 flex-shrink-0">
                                            {service.icon}
                                        </div>
                                        <div>
                                            <h4 className="text-xl font-bold text-white mb-2">{service.title}</h4>
                                            <p className="text-slate-400">{service.description}</p>
                                        </div>
                                    </div>
                                </Card>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
};

export default ServiceCatalog;
