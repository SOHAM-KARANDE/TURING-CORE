
import React from 'react';

const GoToMarket: React.FC = () => {
  const phases = [
    {
      phase: 1,
      title: "Developer Focus",
      description: "Target individual developers and small teams with a generous free tier and an exceptional developer experience."
    },
    {
      phase: 2,
      title: "Business & Enterprise",
      description: "Expand with enterprise-grade features like advanced security, dedicated support, and industry-specific solutions."
    },
    {
      phase: 3,
      title: "International Expansion",
      description: "Systematically enter new geographic markets, localizing the platform and providing regional support."
    }
  ];

  return (
    <section id="strategy" className="py-20 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Go-to-Market Strategy</h2>
          <p className="text-slate-400 mt-4 max-w-2xl mx-auto">A phased approach to building a global AI ecosystem.</p>
        </div>
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-1/2 h-full w-0.5 bg-slate-700 hidden md:block" style={{ transform: 'translateX(-50%)' }}></div>
          
          <div className="space-y-12 md:space-y-0">
            {phases.map((item, index) => (
              <div key={item.phase} className="md:grid md:grid-cols-2 md:gap-x-12 relative">
                <div className={`flex items-center justify-center md:order-${index % 2 === 0 ? 1 : 2}`}>
                  <div className="bg-slate-800 border border-slate-700 rounded-full w-16 h-16 flex items-center justify-center text-cyan-400 text-2xl font-bold z-10">
                    {item.phase}
                  </div>
                </div>
                <div className={`p-6 bg-slate-800 border border-slate-700 rounded-lg md:order-${index % 2 === 0 ? 2 : 1}`}>
                  <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-slate-400">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default GoToMarket;
